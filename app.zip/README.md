# hrm
An opensource hrm software 
